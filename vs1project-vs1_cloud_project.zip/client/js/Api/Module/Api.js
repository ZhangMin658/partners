

export default class Api {
    constructor() {

    }

    
}