Template.invoiceSettings.onRendered(function(){
    $("#showModal2").click(function(){
    $("#currentClaims2").show();
});
$("#closeCurrModel2").click(function(){
    $("#currentClaims2").hide();
})
});